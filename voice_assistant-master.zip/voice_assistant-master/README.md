<p align="center">
 <h3 align="center">Amigo -Voice assistant</h3>

  <p align="center">
   Console Application which help to do your daily work routine.
  </p>
</p>







## About The Project
  Console Application which help to do your daily work routine.

Why Amigo:
* It can search on wikipedia.
* It can open YouTube, Spotify, Whatsapp (if installed on your pc) and other cool stuff.
* You can easily add your command.


### Built With

* Python 3


<!-- USAGE EXAMPLES -->
## Usage
1. It is easy to use just you need is basic Python knowledge
2. You can add your command inside main method by appending ladder if statements.

```
elif 'YOUR VOICE COMMAND' in query:
            speak("YOUR COMMAND")
            ## YOUR CODE
```


<!-- CONTRIBUTING -->
## Contributing

Contributions are what make the open source community such an amazing place to be learn, inspire, and create. Any contributions you make are **greatly appreciated**.

1. Fork the Project
2. Create your Feature Branch 
3. Commit your Changes
4. Push to the Branch
5. Open a Pull Request






<!-- CONTACT -->
## Contact
LinkedIn
[Jaspreet Singh](https://www.linkedin.com/in/jaspreetsidhu13/)

More Projects
GitHub: [JaspreetSidhu3](https://github.com/jaspreetsidhu3)



<!-- ACKNOWLEDGEMENTS -->
## Acknowledgements
* Python 3 language
* wikipedia library
* pyttsx3 library
* os library
* speech_recognition library
* webbrowser library

